#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generates the 6 HTML pages of the Chef Aymen professional website
by wrapping each page's <body> content with a shared head/header/footer.
"""
import os

SITE_URL = "https://your-domain-here.com"  # ⚠️ عدّل هذا لاحقاً برابط موقعك الحقيقي (GitHub Pages أو دومين خاص)
INSTAGRAM = "https://instagram.com/chef_aymen07"  # ⚠️ تأكد من صحة الحساب
WHATSAPP = "https://wa.me/213792289766"
EMAIL = "houssembouabid418@gmail.com"  # ⚠️ استبدله بإيميلك الحقيقي

NAV_ITEMS = [
    ("index.html", "الرئيسية", "Accueil"),
    ("about.html", "من نحن", "À propos"),
    ("menus.html", "قوائمنا", "Nos Menus"),
    ("gallery.html", "معرض الأعمال", "Galerie"),
    ("contact.html", "تواصل معنا", "Contact"),
]

def build_nav(current, mobile=False):
    items = []
    ul_class = "" if not mobile else ""
    for href, ar, fr in NAV_ITEMS:
        active = ' class="active"' if href == current else ""
        items.append(f'<li><a href="{href}"{active}><span data-ar>{ar}</span><span data-fr>{fr}</span></a></li>')
    return "\n        ".join(items)

def page_shell(current, title, desc_ar, desc_fr, body, schema_extra=""):
    nav_desktop = build_nav(current)
    nav_mobile = build_nav(current, mobile=True)
    canonical = f"{SITE_URL}/{current}"
    return f"""<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<meta name="description" content="{desc_ar}">
<link rel="canonical" href="{canonical}">
<meta property="og:type" content="website">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{desc_ar}">
<meta property="og:url" content="{canonical}">
<meta property="og:locale" content="ar_DZ">
<meta property="og:locale:alternate" content="fr_FR">
<meta name="twitter:card" content="summary">
<meta name="robots" content="index, follow">
<link rel="icon" href="favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Cormorant+Garamond:ital,wght@0,400;0,600;1,500&family=Tajawal:wght@300;400;500;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
<script type="application/ld+json">
{{
  "@context": "https://schema.org",
  "@type": "FoodEstablishment",
  "name": "الشاف أيمن - Chef Aymen",
  "image": "{SITE_URL}/og-image.jpg",
  "url": "{SITE_URL}",
  "telephone": "+213792289766",
  "servesCuisine": "الطبخ الجزائري التقليدي",
  "priceRange": "دج",
  "address": {{
    "@type": "PostalAddress",
    "addressRegion": "بسكرة",
    "addressCountry": "DZ"
  }},
  "sameAs": ["{INSTAGRAM}"]
  {schema_extra}
}}
</script>
</head>
<body>

<header>
  <div class="nav-wrap">
    <a href="index.html" class="brand-mini">
      <span class="seal-mini">ش.أ</span>
      <span data-ar>الشاف أيمن</span>
      <span data-fr>Chef Aymen</span>
    </a>
    <div class="nav-cta">
      <nav class="main-nav">
        <ul>
        {nav_desktop}
        </ul>
      </nav>
      <button class="lang-toggle" id="langToggle">FR / عربي</button>
      <a href="booking.html" class="nav-book-btn">
        <span data-ar>احجز الآن</span><span data-fr>Réserver</span>
      </a>
      <button class="burger" id="burger" aria-label="Menu">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
</header>

<div class="mobile-overlay" id="mobileOverlay"></div>
<div class="mobile-menu" id="mobileMenu">
  <button class="mobile-close" id="mobileClose">✕</button>
  <ul>
    {nav_mobile}
    <li><a href="booking.html" class="nav-book-btn" style="display:inline-block; margin-top:10px;"><span data-ar>احجز الآن</span><span data-fr>Réserver</span></a></li>
  </ul>
</div>

{body}

<footer>
  <div class="seal" style="border-color:var(--gold-soft); color:var(--gold-soft);">ش.أ</div>
  <div class="footer-grid">
    <div>
      <h4><span data-ar>الشاف أيمن</span><span data-fr>Chef Aymen</span></h4>
      <ul>
        <li><span data-ar>تراتور وتنظيم ولائم — بسكرة</span><span data-fr>Traiteur & organisation d'événements — Biskra</span></li>
      </ul>
    </div>
    <div>
      <h4><span data-ar>روابط سريعة</span><span data-fr>Liens rapides</span></h4>
      <ul>
        <li><a href="menus.html"><span data-ar>قوائمنا</span><span data-fr>Nos menus</span></a></li>
        <li><a href="gallery.html"><span data-ar>معرض الأعمال</span><span data-fr>Galerie</span></a></li>
        <li><a href="booking.html"><span data-ar>الحجز</span><span data-fr>Réservation</span></a></li>
      </ul>
    </div>
    <div>
      <h4><span data-ar>تواصل</span><span data-fr>Contact</span></h4>
      <ul>
        <li><a href="{INSTAGRAM}" target="_blank">Instagram · @chef_aymen07</a></li>
        <li><a href="{WHATSAPP}" target="_blank">WhatsApp</a></li>
        <li><a href="mailto:{EMAIL}">{EMAIL}</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-fine">
    <span data-ar>© 2026 الشاف أيمن — جميع الحقوق محفوظة</span>
    <span data-fr>© 2026 Chef Aymen — Tous droits réservés</span>
  </div>
</footer>

<a class="float-wa" href="{WHATSAPP}" target="_blank" aria-label="WhatsApp">
  <svg width="26" height="26" viewBox="0 0 24 24" fill="#fff"><path d="M12 2a10 10 0 0 0-8.6 15L2 22l5.2-1.4A10 10 0 1 0 12 2zm0 18a8 8 0 0 1-4.1-1.1l-.3-.2-3 .8.8-2.9-.2-.3A8 8 0 1 1 12 20zm4.4-5.9c-.2-.1-1.4-.7-1.6-.8s-.4-.1-.5.1-.6.8-.7.9-.3.2-.5.1a6.6 6.6 0 0 1-1.9-1.2 7 7 0 0 1-1.3-1.6c-.1-.2 0-.4.1-.5l.4-.4.2-.4c0-.1 0-.3 0-.4s-.5-1.2-.7-1.6-.4-.4-.5-.4h-.5a.9.9 0 0 0-.6.3 2.7 2.7 0 0 0-.9 2 4.7 4.7 0 0 0 1 2.5 10.7 10.7 0 0 0 4.1 3.6c.6.2 1 .4 1.4.5a3.3 3.3 0 0 0 1.5.1 2.5 2.5 0 0 0 1.6-1.1 1.9 1.9 0 0 0 .1-1.1c-.1-.1-.2-.2-.4-.3z"/></svg>
</a>

<script src="script.js"></script>
</body>
</html>
"""

if __name__ == "__main__":
    print("Module loaded — import page bodies from pages_content.py")

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, '.')
from build import page_shell

# =========================================================
# ICONS (small reusable inline SVGs, stroke-based, gold-colored via currentColor)
# =========================================================
ICON = {
    "clock": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>',
    "globe": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18z"/></svg>',
    "menu": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><circle cx="12" cy="13" r="8"/><path d="M6 13a6 6 0 0 0 12 0"/></svg>',
    "check": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M4 12l6 6L20 6"/></svg>',
    "checkmark": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M4 12l6 6L20 6"/></svg>',
    "couscous": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><circle cx="12" cy="13" r="8"/><path d="M6 13a6 6 0 0 0 12 0"/><path d="M9 5c0 1-1 1-1 2s1 1 1 2M15 5c0 1 1 1 1 2s-1 1-1 2"/></svg>',
    "mechoui": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M4 20l7-7"/><path d="M13 11l6-6"/><circle cx="17" cy="6" r="2"/><path d="M4 20l3-8"/></svg>',
    "dessert": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="4" y="10" width="16" height="8" rx="1"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>',
    "camera": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="3" y="7" width="18" height="13" rx="2"/><circle cx="12" cy="13.5" r="3.5"/><path d="M8 7l1.5-3h5L16 7"/></svg>',
    "phone": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M4 5c0 8 7 15 15 15l3-4-6-3-2 2c-2-1-4-3-5-5l2-2-3-6z"/></svg>',
    "mail": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>',
    "pin": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M12 22s7-7.5 7-13a7 7 0 0 0-14 0c0 5.5 7 13 7 13z"/><circle cx="12" cy="9" r="2.5"/></svg>',
    "insta": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1"/></svg>',
}

def feat(icon, ar_title, fr_title, ar_body, fr_body):
    return f'''<div class="feature-card reveal">
      <div class="feature-icon">{ICON[icon]}</div>
      <h3><span data-ar>{ar_title}</span><span data-fr>{fr_title}</span></h3>
      <p><span data-ar>{ar_body}</span><span data-fr>{fr_body}</span></p>
    </div>'''

# =========================================================
# INDEX
# =========================================================
index_body = f'''
<section class="hero">
  <div class="hero-frame">
    <span class="corner tl"></span><span class="corner tr"></span>
    <span class="corner bl"></span><span class="corner br"></span>
    <div class="seal">ش.أ</div>
    <div class="eyebrow"><span data-ar>تراتور و تنظيم الولائم</span><span data-fr>Traiteur & Organisation d'Événements</span></div>
    <h1><span data-ar>الشاف أيمن</span><span data-fr>Chef Aymen</span></h1>
    <p class="tagline"><span data-ar>نكهة الأصالة تُقدَّم بلمسة احترافية، في كل عرس وكل مناسبة</span><span data-fr>Le goût de l'authenticité, servi avec une touche professionnelle</span></p>
    <div class="hero-ctas">
      <a href="booking.html" class="btn"><span data-ar>احجز مناسبتك</span><span data-fr>Réserver votre événement</span></a>
      <a href="menus.html" class="btn btn-outline"><span data-ar>شاهد قوائمنا</span><span data-fr>Voir nos menus</span></a>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="kicker"><span data-ar>لماذا نحن</span><span data-fr>Pourquoi nous</span></div>
    <h2 class="section-title reveal"><span data-ar>خبرة تُذاق قبل أن تُروى</span><span data-fr>Une expérience qui se goûte avant de se raconter</span></h2>
    <div class="divider"></div>
    <div class="feature-grid">
      {feat("clock", "التزام بالمواعيد", "Ponctualité", "تنظيم دقيق لكل مرحلة من التحضير إلى التقديم في الوقت المحدد.", "Une organisation précise, de la préparation au service, à l'heure exacte.")}
      {feat("globe", "تنسيق متعدد اللغات", "Coordination multilingue", "نتواصل بالعربية والفرنسية والإنجليزية لخدمة كل عميل بلغته.", "Nous communiquons en arabe, français et anglais pour chaque client.")}
      {feat("menu", "قوائم مخصصة", "Menus personnalisés", "نصمم القائمة حسب ذوقكم وميزانيتكم وعدد ضيوفكم.", "Nous adaptons le menu à votre goût, budget et nombre d'invités.")}
      {feat("check", "جودة مضمونة", "Qualité garantie", "مكونات طازجة وفريق مُجرَّب في كل وليمة.", "Ingrédients frais et équipe expérimentée à chaque événement.")}
    </div>
  </div>
</section>

<section class="section-alt">
  <div class="wrap">
    <div class="kicker"><span data-ar>لمحة عن قوائمنا</span><span data-fr>Aperçu de nos menus</span></div>
    <h2 class="section-title reveal"><span data-ar>نكهات تُعِدّها أيدٍ خبيرة</span><span data-fr>Des saveurs préparées par des mains expertes</span></h2>
    <div class="divider"></div>
    <div class="feature-grid">
      {feat("mechoui", "اللحم والدجاج", "Viande & Poulet", "مفور، برمة، مشوي، فور — بأنواعه.", "Grillé, mijoté, rôti — dans plusieurs styles.")}
      {feat("couscous", "المقبلات والسلطات والحساء", "Entrées, salades & soupes", "تشكيلة واسعة من المقبلات التقليدية والعصرية.", "Un large choix d'entrées traditionnelles et modernes.")}
      {feat("couscous", "الطبق الرئيسي", "Plat Principal", "طاجين، كبسة، شخشوخة، تليتلي وأكثر.", "Tajine, kabsa, chakhchoukha, tliteli et plus.")}
      {feat("dessert", "التحلية", "Dessert", "أطباق حلوة تقليدية بلمسة أنيقة.", "Desserts traditionnels présentés avec élégance.")}
    </div>
    <p class="section-sub reveal" style="margin-top:34px;">
      <span data-ar>250 دج للفرد الواحد — شامل 4 أطباق من اختياركم من القائمة الكاملة</span>
      <span data-fr>250 DA par personne — 4 plats au choix parmi le menu complet</span>
    </p>
    <div style="text-align:center; margin-top:24px;">
      <a href="menus.html" class="btn"><span data-ar>شاهد القائمة الكاملة</span><span data-fr>Voir le menu complet</span></a>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="kicker"><span data-ar>بالأرقام</span><span data-fr>En chiffres</span></div>
    <h2 class="section-title reveal"><span data-ar>ثقة عملائنا هي الأهم</span><span data-fr>La confiance de nos clients avant tout</span></h2>
    <div class="divider"></div>
    <div class="stats">
      <div class="stat reveal"><b>+150</b><span data-ar>مناسبة أُقيمت</span><span data-fr>Événements réalisés</span></div>
      <div class="stat reveal"><b>+12</b><span data-ar>عضو في الفريق</span><span data-fr>Membres d'équipe</span></div>
      <div class="stat reveal"><b>3</b><span data-ar>لغات تنسيق</span><span data-fr>Langues de coordination</span></div>
    </div>
    <p class="form-note" style="margin-top:30px;"><span data-ar>* أرقام تقريبية توضيحية — عدّلها لتعكس مسيرتك الحقيقية.</span><span data-fr>* Chiffres indicatifs — à ajuster selon votre parcours réel.</span></p>
  </div>
</section>

<section class="section-alt" style="text-align:center;">
  <div class="wrap-narrow">
    <h2 class="section-title reveal"><span data-ar>جاهزون لجعل مناسبتكم لا تُنسى</span><span data-fr>Prêts à rendre votre événement inoubliable</span></h2>
    <p class="section-sub"><span data-ar>احجزوا الآن وسنتواصل معكم خلال 24 ساعة لتحديد كل التفاصيل.</span><span data-fr>Réservez maintenant, nous vous contactons sous 24h pour finaliser les détails.</span></p>
    <a href="booking.html" class="btn" style="margin-top:26px;"><span data-ar>احجز مناسبتك الآن</span><span data-fr>Réservez maintenant</span></a>
  </div>
</section>
'''

# =========================================================
# ABOUT
# =========================================================
about_body = f'''
<section class="page-hero">
  <div class="kicker"><span data-ar>تعريف</span><span data-fr>Présentation</span></div>
  <h1><span data-ar>من نحن</span><span data-fr>À propos de nous</span></h1>
  <p><span data-ar>قصة شغف بالطبخ الأصيل والتنظيم المُتقن</span><span data-fr>Une histoire de passion pour la cuisine authentique et l'organisation soignée</span></p>
  <div class="breadcrumb"><a href="index.html"><span data-ar>الرئيسية</span><span data-fr>Accueil</span></a> / <span data-ar>من نحن</span><span data-fr>À propos</span></div>
</section>

<section>
  <div class="wrap-narrow" style="text-align:center;">
    <p class="reveal" style="font-size:1.05rem; color:var(--ink-soft);">
      <span data-ar>منذ سنوات ونحن نتولى تنظيم الولائم والأعراس بروح تجمع بين النكهة الأصيلة والدقة في التنظيم. فريقنا يهتم بأدق التفاصيل، من إعداد القوائم إلى تنسيق الفريق يوم المناسبة، لنمنحكم يوماً بلا قلق وذكرى تستحق أن تُروى.</span>
      <span data-fr>Depuis plusieurs années, nous organisons mariages et événements avec un esprit qui allie saveur authentique et rigueur d'organisation. Notre équipe soigne chaque détail, de la préparation des menus à la coordination le jour J.</span>
    </p>
  </div>
</section>

<section class="section-alt">
  <div class="wrap-narrow">
    <div class="kicker"><span data-ar>مسيرتنا</span><span data-fr>Notre parcours</span></div>
    <h2 class="section-title reveal"><span data-ar>محطات في طريق الشغف</span><span data-fr>Étapes d'un parcours passionné</span></h2>
    <div class="divider"></div>
    <div class="timeline">
      <div class="tl-item reveal">
        <h3><span data-ar>البداية</span><span data-fr>Les débuts</span></h3>
        <p><span data-ar>انطلقنا بولائم صغيرة داخل العائلة والمعارف، بشغف حقيقي للطبخ التقليدي.</span><span data-fr>Nous avons commencé par de petits événements familiaux, avec une vraie passion pour la cuisine traditionnelle.</span></p>
      </div>
      <div class="tl-item reveal">
        <h3><span data-ar>بناء الفريق</span><span data-fr>Constitution de l'équipe</span></h3>
        <p><span data-ar>توسّعنا وكوّنّا فريقاً متخصصاً في الطبخ والتنسيق واللوجستيك.</span><span data-fr>Nous nous sommes développés avec une équipe spécialisée en cuisine, coordination et logistique.</span></p>
      </div>
      <div class="tl-item reveal">
        <h3><span data-ar>اليوم</span><span data-fr>Aujourd'hui</span></h3>
        <p><span data-ar>نخدم أعراساً ومناسبات في بسكرة والمناطق المجاورة بمعايير احترافية.</span><span data-fr>Nous servons mariages et événements à Biskra et ses environs avec des standards professionnels.</span></p>
      </div>
    </div>
    <p class="form-note"><span data-ar>* عدّل هذه المحطات بتفاصيل قصتك الحقيقية.</span><span data-fr>* Personnalisez ces étapes avec votre histoire réelle.</span></p>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="kicker"><span data-ar>طريقة عملنا</span><span data-fr>Notre méthode</span></div>
    <h2 class="section-title reveal"><span data-ar>كيف نُحضّر ليومكم الكبير</span><span data-fr>Comment nous préparons votre grand jour</span></h2>
    <div class="divider"></div>
    <div class="feature-grid">
      {feat("mail", "استشارة أولى", "Première consultation", "نستمع لرغباتكم وعدد ضيوفكم وميزانيتكم.", "Nous écoutons vos souhaits, le nombre d'invités et votre budget.")}
      {feat("menu", "تصميم القائمة", "Conception du menu", "نقترح قوائم مناسبة ونعدّلها حسب رغبتكم.", "Nous proposons des menus adaptés et les ajustons selon vos préférences.")}
      {feat("clock", "التحضير", "Préparation", "فريقنا يحضّر كل شيء بدقة قبل يوم المناسبة.", "Notre équipe prépare tout avec précision avant le jour J.")}
      {feat("check", "التقديم", "Le jour J", "نكون حاضرين لضمان تقديم مثالي في الوقت المحدد.", "Nous sommes présents pour garantir un service parfait à l'heure.")}
    </div>
  </div>
</section>
'''

# =========================================================
# MENUS — القائمة الحقيقية
# =========================================================
MENU_CATEGORIES = [
    ("meat", "اللحم", "Viande", ["مفور", "برمة", "مشوي", "فور"]),
    ("chicken", "دجاج كويس", "Poulet", ["مفور", "برمة", "مشوي", "مقلي", "فور"]),
    ("starters", "المقبلات", "Entrées", ["بابا غنوش", "طحينية", "حميس", "بوراك", "عين الجمل", "زيتون مشكل", "بريك"]),
    ("salads", "السلطات", "Salades", ["أوردافر", "سيزار", "فار", "توريك", "تونسية", "سلطة شرقية", "بات فرماج"]),
    ("soups", "الحساء", "Soupes", ["شربة فريك", "حريرة", "شربة بيضة", "سوب دوروس", "سوب شامبينون"]),
    ("main", "الطبق الرئيسي", "Plat Principal", ["طعام (بربوشة)", "طاجين الزيتون", "طاجين بوناريت", "طاجين كفتة", "أجيد رولي", "طاجين جبن", "كبسة سعودية", "شخشوخة", "شخشوخة الظفر", "تليتلي أحمر", "تليتلي أبيض", "رشتة", "مثوم"]),
    ("dessert", "تحلية", "Dessert", ["طاجين حلو ديكوراسيون", "مسفوف", "طبق ديسار", "تارتيلات", "طاجين شباح", "طاجين حلو"]),
]

CAT_ICON = {
    "meat": "mechoui", "chicken": "mechoui", "starters": "couscous",
    "salads": "couscous", "soups": "couscous", "main": "couscous", "dessert": "dessert"
}

def menu_category(key, ar_name, fr_name, items):
    li = "".join(f"<li>{i}</li>" for i in items)
    return f'''<div class="menu-card reveal">
      <div class="menu-icon">{ICON[CAT_ICON[key]]}</div>
      <h3><span data-ar>{ar_name}</span><span data-fr>{fr_name}</span></h3>
      <ul class="menu-list">{li}</ul>
    </div>'''

menu_categories_html = "\n      ".join(
    menu_category(k, ar, fr, items) for k, ar, fr, items in MENU_CATEGORIES
)

menus_body = f'''
<section class="page-hero">
  <div class="kicker"><span data-ar>قوائم الطعام</span><span data-fr>Nos Menus</span></div>
  <h1><span data-ar>قائمتنا الكاملة</span><span data-fr>Notre menu complet</span></h1>
  <p><span data-ar>تشكيلة واسعة من الأطباق — اختاروا ما يناسب ذوقكم</span><span data-fr>Un large choix de plats — sélectionnez selon vos préférences</span></p>
  <div class="breadcrumb"><a href="index.html"><span data-ar>الرئيسية</span><span data-fr>Accueil</span></a> / <span data-ar>قوائمنا</span><span data-fr>Nos Menus</span></div>
</section>

<section class="section-alt" style="text-align:center; padding-bottom:60px;">
  <div class="wrap-narrow">
    <div class="kicker"><span data-ar>السعر</span><span data-fr>Tarif</span></div>
    <div class="pkg-price" style="font-size:2.4rem;">250 <small data-ar>دج للفرد الواحد</small><small data-fr>DA par personne</small></div>
    <p class="section-sub" style="margin-top:10px;">
      <span data-ar>شامل 4 أطباق من اختياركم من القائمة الكاملة أدناه</span>
      <span data-fr>4 plats au choix parmi le menu complet ci-dessous</span>
    </p>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="kicker"><span data-ar>الأصناف</span><span data-fr>Catégories</span></div>
    <h2 class="section-title reveal"><span data-ar>القائمة الكاملة</span><span data-fr>Le menu complet</span></h2>
    <div class="divider"></div>
    <div class="menu-grid" style="grid-template-columns:repeat(auto-fit, minmax(240px,1fr));">
      {menu_categories_html}
    </div>
    <p class="form-note" style="margin-top:40px;">
      <span data-ar>* اختاروا 4 أطباق من أي صنف تحبون (يمكن الجمع بين أصناف مختلفة) بسعر 250 دج للفرد الواحد. للكميات الكبيرة أو التخصيص الإضافي، تواصلوا معنا مباشرة.</span>
      <span data-fr>* Choisissez 4 plats parmi les catégories de votre choix (combinaisons possibles) pour 250 DA par personne. Pour les grandes quantités ou personnalisations, contactez-nous directement.</span>
    </p>
    <div style="text-align:center; margin-top:30px;">
      <a href="booking.html" class="btn"><span data-ar>احجز الآن</span><span data-fr>Réserver maintenant</span></a>
    </div>
  </div>
</section>
'''

# =========================================================
# GALLERY
# =========================================================
GALLERY_IMAGES = [
    ("dessert-fruit-plate-1.jpg", "dessert"),
    ("appetizer-eggplant-1.jpg", "starters"),
    ("appetizer-mousse-rolls.jpg", "starters"),
    ("main-kabsa-rice.jpg", "mains"),
    ("appetizer-fried-rolls-1.jpg", "starters"),
    ("dessert-fruit-platter.jpg", "dessert"),
    ("soup-harira-bowls.jpg", "starters"),
    ("main-chicken-olives-1.jpg", "mains"),
    ("appetizer-canape-squares.jpg", "starters"),
    ("main-chicken-skewers-1.jpg", "mains"),
    ("appetizer-green-dip.jpg", "starters"),
    ("main-roasted-chicken-1.jpg", "mains"),
    ("dessert-grapes-peaches.jpg", "dessert"),
    ("main-chicken-olives-2.jpg", "mains"),
    ("appetizer-egg-salad-glasses.jpg", "starters"),
    ("appetizer-fried-rolls-2.jpg", "starters"),
    ("main-chicken-bread-olives.jpg", "mains"),
    ("main-chicken-skewers-2.jpg", "mains"),
    ("dessert-dried-fruits-nuts.jpg", "dessert"),
    ("appetizer-eggplant-2.jpg", "starters"),
]

def gframe(img, cat, idx):
    delay = (idx % 4) * 0.08
    return f'''<div class="gframe reveal" data-cat="{cat}" style="transition-delay:{delay:.2f}s;" onclick="openLightbox('images/{img}')">
      <img src="images/{img}" alt="طبق من تحضيرات الشاف أيمن" loading="lazy">
    </div>'''

gallery_grid = "\n      ".join(gframe(img, cat, i) for i, (img, cat) in enumerate(GALLERY_IMAGES))

gallery_body = f'''
<section class="page-hero">
  <div class="kicker"><span data-ar>أعمالنا</span><span data-fr>Notre travail</span></div>
  <h1><span data-ar>معرض الأعمال</span><span data-fr>Galerie</span></h1>
  <p><span data-ar>لمحة من الولائم والمناسبات التي أعددناها</span><span data-fr>Un aperçu des événements que nous avons réalisés</span></p>
  <div class="breadcrumb"><a href="index.html"><span data-ar>الرئيسية</span><span data-fr>Accueil</span></a> / <span data-ar>معرض الأعمال</span><span data-fr>Galerie</span></div>
</section>

<section>
  <div class="wrap">
    <div class="gallery-tabs">
      <button class="gtab active" data-filter="all"><span data-ar>الكل</span><span data-fr>Tout</span></button>
      <button class="gtab" data-filter="starters"><span data-ar>المقبلات والسلطات</span><span data-fr>Entrées & Salades</span></button>
      <button class="gtab" data-filter="mains"><span data-ar>الدجاج والأطباق الرئيسية</span><span data-fr>Poulet & Plats principaux</span></button>
      <button class="gtab" data-filter="dessert"><span data-ar>الحلويات والفواكه</span><span data-fr>Desserts & Fruits</span></button>
    </div>
    <div class="gallery-grid">
      {gallery_grid}
    </div>
  </div>
</section>

<div class="lightbox" id="lightbox" onclick="closeLightbox()">
  <span class="lightbox-close">&times;</span>
  <img id="lightboxImg" src="" alt="">
</div>
'''

# =========================================================
# BOOKING
# =========================================================
booking_body = f'''
<section class="page-hero">
  <div class="kicker"><span data-ar>الحجز</span><span data-fr>Réservation</span></div>
  <h1><span data-ar>احجزوا مناسبتكم</span><span data-fr>Réservez votre événement</span></h1>
  <p><span data-ar>عبّئوا النموذج وسنتواصل معكم لتأكيد كل التفاصيل</span><span data-fr>Remplissez le formulaire, nous vous contacterons pour confirmer les détails</span></p>
  <div class="breadcrumb"><a href="index.html"><span data-ar>الرئيسية</span><span data-fr>Accueil</span></a> / <span data-ar>الحجز</span><span data-fr>Réservation</span></div>
</section>

<section>
  <div class="wrap">
    <div class="card-panel">
      <span class="corner tl" style="border-color:var(--gold)"></span><span class="corner tr" style="border-color:var(--gold)"></span>
      <span class="corner bl" style="border-color:var(--gold)"></span><span class="corner br" style="border-color:var(--gold)"></span>

      <p class="required-note"><span data-ar>الحقول المُعلَّمة (*) إلزامية</span><span data-fr>Les champs marqués (*) sont obligatoires</span></p>

      <form id="bookingForm">
        <div class="field-row">
          <div class="field">
            <label><span data-ar>الاسم الكامل *</span><span data-fr>Nom complet *</span></label>
            <input type="text" id="f_name" required>
          </div>
          <div class="field">
            <label><span data-ar>رقم الهاتف *</span><span data-fr>Téléphone *</span></label>
            <input type="tel" id="f_phone" required placeholder="+213 6XX XX XX XX">
          </div>
        </div>
        <div class="field-row">
          <div class="field">
            <label><span data-ar>تاريخ المناسبة *</span><span data-fr>Date de l'événement *</span></label>
            <input type="date" id="f_date" required>
          </div>
          <div class="field">
            <label><span data-ar>عدد الضيوف *</span><span data-fr>Nombre d'invités *</span></label>
            <input type="number" id="f_guests" min="1" required placeholder="150">
          </div>
        </div>
        <div class="field-row">
          <div class="field">
            <label><span data-ar>نوع المناسبة</span><span data-fr>Type d'événement</span></label>
            <select id="f_type">
              <option data-ar="زفاف" data-fr="Mariage" selected>زفاف / Mariage</option>
              <option data-ar="خطوبة" data-fr="Fiançailles">خطوبة / Fiançailles</option>
              <option data-ar="عقيقة" data-fr="Aqiqa">عقيقة / Aqiqa</option>
              <option data-ar="مناسبة شركة" data-fr="Événement d'entreprise">مناسبة شركة / Entreprise</option>
              <option data-ar="أخرى" data-fr="Autre">أخرى / Autre</option>
            </select>
          </div>
          <div class="field">
            <label><span data-ar>هل حددتم الأطباق الأربعة؟</span><span data-fr>Avez-vous choisi vos 4 plats ?</span></label>
            <select id="f_menu">
              <option data-ar="نعم، مذكورة في الملاحظات" data-fr="Oui, indiqués dans les notes" selected>نعم، مذكورة في الملاحظات / Oui, indiqués</option>
              <option data-ar="لا، بحاجة لاقتراحات" data-fr="Non, besoin de suggestions">لا، بحاجة لاقتراحات / Besoin de suggestions</option>
            </select>
          </div>
        </div>
        <div class="field">
          <label><span data-ar>الأطباق الأربعة المختارة (اكتبوها هنا) / ملاحظات إضافية</span><span data-fr>Vos 4 plats choisis / Notes additionnelles</span></label>
          <textarea id="f_notes" rows="3" placeholder="مثال: مشوي، طاجين الزيتون، حريرة، مسفوف"></textarea>
        </div>

        <div class="form-actions">
          <button type="submit" class="btn" id="submitBooking">
            <span data-ar>إرسال الطلب</span><span data-fr>Envoyer la demande</span>
          </button>
          <button type="button" class="btn" id="sendWaBackup" style="background:#25D366; color:#fff;">
            <span data-ar>أو أرسل عبر واتساب</span><span data-fr>Ou envoyer via WhatsApp</span>
          </button>
        </div>
        <div class="form-status" id="formStatus"></div>
        <p class="form-note"><span data-ar>سيتم تسجيل طلبك مباشرة في نظامنا وسنتواصل معك خلال 24 ساعة.</span><span data-fr>Votre demande sera enregistrée directement et nous vous contacterons sous 24h.</span></p>
      </form>
    </div>
  </div>
</section>

<section class="section-alt">
  <div class="wrap-narrow">
    <div class="kicker"><span data-ar>أسئلة شائعة</span><span data-fr>Questions fréquentes</span></div>
    <h2 class="section-title reveal"><span data-ar>قبل أن تحجزوا</span><span data-fr>Avant de réserver</span></h2>
    <div class="divider"></div>
    <div class="faq" style="color:var(--ivory);">
      <div class="faq-item">
        <button class="faq-q"><span><span data-ar>هل يلزم دفع عربون عند الحجز؟</span><span data-fr>Un acompte est-il requis à la réservation ?</span></span><span class="plus">+</span></button>
        <div class="faq-a"><div class="faq-a-inner"><span data-ar>نعم، عادةً نطلب عربوناً لتأكيد الحجز، والباقي يُدفع يوم المناسبة. التفاصيل تُحدَّد عند التواصل معكم.</span><span data-fr>Oui, un acompte est généralement demandé pour confirmer la réservation, le reste étant réglé le jour de l'événement.</span></div></div>
      </div>
      <div class="faq-item">
        <button class="faq-q"><span><span data-ar>كم من الوقت قبل المناسبة يجب الحجز؟</span><span data-fr>Combien de temps à l'avance faut-il réserver ?</span></span><span class="plus">+</span></button>
        <div class="faq-a"><div class="faq-a-inner"><span data-ar>ننصح بالحجز قبل 3 إلى 4 أسابيع على الأقل لضمان التوفر الكامل.</span><span data-fr>Nous recommandons de réserver au moins 3 à 4 semaines à l'avance.</span></div></div>
      </div>
      <div class="faq-item">
        <button class="faq-q"><span><span data-ar>هل يمكن تخصيص القائمة حسب رغبتنا؟</span><span data-fr>Peut-on personnaliser le menu selon nos envies ?</span></span><span class="plus">+</span></button>
        <div class="faq-a"><div class="faq-a-inner"><span data-ar>بالتأكيد، نناقش معكم كل التفاصيل ونقترح تعديلات تناسب ذوقكم وميزانيتكم.</span><span data-fr>Bien sûr, nous discutons de tous les détails et proposons des ajustements selon vos goûts.</span></div></div>
      </div>
    </div>
  </div>
</section>
'''

# =========================================================
# CONTACT
# =========================================================
contact_body = f'''
<section class="page-hero">
  <div class="kicker"><span data-ar>تواصل معنا</span><span data-fr>Contactez-nous</span></div>
  <h1><span data-ar>نحن هنا للإجابة على استفساراتكم</span><span data-fr>Nous sommes là pour répondre à vos questions</span></h1>
  <div class="breadcrumb"><a href="index.html"><span data-ar>الرئيسية</span><span data-fr>Accueil</span></a> / <span data-ar>تواصل معنا</span><span data-fr>Contact</span></div>
</section>

<section>
  <div class="wrap">
    <div class="contact-grid">
      <div class="contact-card reveal">
        {ICON["phone"]}
        <h3><span data-ar>الهاتف / واتساب</span><span data-fr>Téléphone / WhatsApp</span></h3>
        <p><a href="https://wa.me/213792289766" target="_blank">+213 792 28 97 66</a></p>
      </div>
      <div class="contact-card reveal">
        {ICON["mail"]}
        <h3><span data-ar>البريد الإلكتروني</span><span data-fr>E-mail</span></h3>
        <p><a href="mailto:houssembouabid418@gmail.com">houssembouabid418@gmail.com</a></p>
      </div>
      <div class="contact-card reveal">
        {ICON["pin"]}
        <h3><span data-ar>المنطقة</span><span data-fr>Zone desservie</span></h3>
        <p><span data-ar>بسكرة والمناطق المجاورة</span><span data-fr>Biskra et environs</span></p>
      </div>
      <div class="contact-card reveal">
        {ICON["insta"]}
        <h3>Instagram</h3>
        <p><a href="https://instagram.com/chef_aymen07" target="_blank">@chef_aymen07</a></p>
      </div>
    </div>

    <div class="map-wrap reveal">
      <iframe src="https://maps.google.com/maps?q=Biskra%2C%20Algeria&t=&z=11&ie=UTF8&iwloc=&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <p class="form-note"><span data-ar>* الخريطة تعرض منطقة بسكرة بشكل عام. حدّد موقعك الدقيق إذا أردت (اختياري).</span><span data-fr>* La carte montre la région de Biskra en général. Précisez votre emplacement exact si souhaité (optionnel).</span></p>
  </div>
</section>
'''

# =========================================================
# BUILD ALL
# =========================================================
pages = [
    ("index.html", "الشاف أيمن | Chef Aymen — تراتور وتنظيم الولائم في بسكرة",
     "خدمات تراتور وتنظيم ولائم وأعراس احترافية في بسكرة، بقوائم طعام أصيلة وتنسيق متعدد اللغات.",
     "Services de traiteur et d'organisation de mariages à Biskra, menus authentiques et coordination multilingue.",
     index_body),
    ("about.html", "من نحن | الشاف أيمن — Chef Aymen",
     "تعرّفوا على قصة الشاف أيمن وفريقنا المتخصص في تنظيم الولائم والأعراس.",
     "Découvrez l'histoire de Chef Aymen et notre équipe spécialisée en organisation d'événements.",
     about_body),
    ("menus.html", "قوائمنا وباقاتنا | الشاف أيمن — Chef Aymen",
     "اكتشفوا قوائم الطعام والباقات المتوفرة لدى الشاف أيمن: كسكسي، مشوي، حلويات وأكثر.",
     "Découvrez nos menus et forfaits : couscous, méchoui, pâtisseries et plus encore.",
     menus_body),
    ("gallery.html", "معرض الأعمال | الشاف أيمن — Chef Aymen",
     "لمحة عن الولائم والمناسبات التي نظّمها فريق الشاف أيمن.",
     "Un aperçu des événements organisés par l'équipe de Chef Aymen.",
     gallery_body),
    ("booking.html", "احجز مناسبتك | الشاف أيمن — Chef Aymen",
     "احجزوا وليمتكم أو مناسبتكم مع الشاف أيمن عبر نموذج الحجز السريع.",
     "Réservez votre événement avec Chef Aymen via notre formulaire de réservation rapide.",
     booking_body),
    ("contact.html", "تواصل معنا | الشاف أيمن — Chef Aymen",
     "تواصلوا مع فريق الشاف أيمن عبر الهاتف، واتساب، البريد الإلكتروني أو انستغرام.",
     "Contactez l'équipe de Chef Aymen par téléphone, WhatsApp, e-mail ou Instagram.",
     contact_body),
]

for fname, title, desc_ar, desc_fr, body in pages:
    html = page_shell(fname, title, desc_ar, desc_fr, body)
    with open(fname, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"✓ {fname}")

print("\\nDone.")
